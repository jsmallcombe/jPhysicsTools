TODO
====

- Compare results against http://fy.chalmers.se/subatom/wigxjpf/
